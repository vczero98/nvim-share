---@meta
local resty_core_time = {}
resty_core_time.version = require("resty.core.base").version
return resty_core_time
