---@meta
local resty_core = {}
resty_core.version = require("resty.core.base").version
return resty_core
