---@meta

---@class cc.Layer :cc.Node
local Layer = {}
cc.Layer = Layer

---*  Creates a fullscreen black layer.<br>
---* return An autoreleased Layer object.
---@return self
function Layer:create() end
---*
---@return boolean
function Layer:init() end
---*
---@return string
function Layer:getDescription() end
---*
---@return self
function Layer:Layer() end
