---@meta

---@class cc.TiledGrid3DAction :cc.GridAction
local TiledGrid3DAction = {}
cc.TiledGrid3DAction = TiledGrid3DAction

---*
---@return self
function TiledGrid3DAction:clone() end
---*  returns the grid
---@return cc.GridBase
function TiledGrid3DAction:getGrid() end
