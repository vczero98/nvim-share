---@meta

---@class cc.EventListenerMouse :cc.EventListener
local EventListenerMouse = {}
cc.EventListenerMouse = EventListenerMouse

---*
---@return boolean
function EventListenerMouse:init() end
---* / Overrides
---@return self
function EventListenerMouse:clone() end
---*
---@return boolean
function EventListenerMouse:checkAvailable() end
---*
---@return self
function EventListenerMouse:EventListenerMouse() end
